#include "stdafx.h"
#include "CCluster.h"


CCluster::CCluster()
{
}


CCluster::~CCluster()
{
}
