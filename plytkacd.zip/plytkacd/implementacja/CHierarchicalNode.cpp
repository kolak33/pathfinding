#include "stdafx.h"
#include "CHierarchicalNode.h"


CHierarchicalNode::CHierarchicalNode()
{
}


CHierarchicalNode::~CHierarchicalNode()
{
}
