#include "stdafx.h"
#include "CHierarchicalEdge.h"


CHierarchicalEdge::CHierarchicalEdge()
{
}


CHierarchicalEdge::~CHierarchicalEdge()
{
}
