#include "stdafx.h"
#include "CGridTile.h"


CGridTile::CGridTile() : m_gridTypeEnum(GridTypeNone)
{
}


CGridTile::~CGridTile()
{

}
