// stdafx.h: dołącz plik do standardowych systemowych plików dołączanych,
// lub specyficzne dla projektu pliki dołączane, które są często wykorzystywane, ale
// są rzadko zmieniane
//

#pragma once

#include "targetver.h"
#include <iostream>
//#include <stdio.h>
#include <tchar.h>



// TODO: W tym miejscu odwołaj się do dodatkowych nagłówków wymaganych przez program
